﻿require(['./config'], function (common) {    
    require(['jquery', 'jquery.validate'], function ($) {
        require(['jquery.validate.unobtrusive']);
    });
})
